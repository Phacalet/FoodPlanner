// ⚠️ Fichier provisoire : il sera REMPLACÉ automatiquement par la commande
//    flutterfire configure
// (voir README.md, étape 2). Il permet juste au projet de compiler.
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform => throw UnsupportedError(
        'Lancez « flutterfire configure » pour relier l\'app à votre projet Firebase.',
      );
}
